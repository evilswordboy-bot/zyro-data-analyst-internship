import pandas as pd
import json

df = pd.read_csv('data/rides_data_week3.csv')
df['rating'] = df['rating'].where(pd.notnull(df['rating']), None)
records = df.to_dict(orient='records')

html_content = f"""<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ZYROO • Power BI Ride Analytics & Revenue Intelligence Command Center</title>
  <script src="tailwindcss.min.js"></script>
  <script>
    if (!window.tailwind) {{
      document.write('<script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"><\\/script>');
    }}
  </script>
  <style>
    :root {{
      --bg-primary: #080d1a;
      --surface-1: #0f172a;
      --border-subtle: rgba(56, 189, 248, 0.12);
      --border-accent: rgba(0, 229, 255, 0.35);
    }}
    body {{
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background-color: var(--bg-primary);
      color: #f1f5f9;
      background-image: 
        radial-gradient(at 10% 10%, rgba(14, 165, 233, 0.08) 0px, transparent 50%),
        radial-gradient(at 90% 90%, rgba(99, 102, 241, 0.06) 0px, transparent 50%);
      background-attachment: fixed;
    }}
    .font-mono-num {{
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-variant-numeric: tabular-nums;
    }}
    .acrylic-card {{
      background: linear-gradient(135deg, rgba(15, 23, 42, 0.92), rgba(15, 23, 42, 0.75));
      backdrop-filter: blur(12px);
      border: 1px solid var(--border-subtle);
      box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
      transition: all 0.25s ease;
    }}
    .acrylic-card:hover {{
      border-color: var(--border-accent);
      box-shadow: 0 12px 35px -8px rgba(0, 229, 255, 0.14);
    }}
    .custom-scrollbar::-webkit-scrollbar {{
      width: 6px;
      height: 6px;
    }}
    .custom-scrollbar::-webkit-scrollbar-track {{
      background: #0f172a;
    }}
    .custom-scrollbar::-webkit-scrollbar-thumb {{
      background: #334155;
      border-radius: 9999px;
    }}
  </style>
</head>
<body class="min-h-screen p-4 sm:p-6 lg:p-8 antialiased">
  <div class="max-w-[1650px] mx-auto space-y-6">

    <!-- TOP HEADER -->
    <header class="acrylic-card rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-slate-950 font-black text-xl tracking-tighter shadow-lg shadow-cyan-500/20">
          ZY
        </div>
        <div>
          <div class="flex items-center gap-2.5 flex-wrap">
            <span class="text-xs font-black uppercase tracking-widest text-cyan-400 px-2.5 py-0.5 rounded-md bg-cyan-500/10 border border-cyan-500/20">ZYROO Intelligence</span>
            <span class="text-xs text-slate-400">Week 4 • Power BI Dashboard Architecture</span>
            <span class="inline-flex items-center gap-1.5 px-2 py-0.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              Production Ready
            </span>
          </div>
          <h1 class="text-xl sm:text-2xl font-extrabold tracking-tight text-white mt-1">
            Ride Analytics & <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400">Revenue Intelligence Platform</span>
          </h1>
        </div>
      </div>

      <div class="flex items-center gap-3 self-end md:self-center">
        <button onclick="downloadCSV()" class="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-2">
          Export Filtered CSV
        </button>
        <button onclick="resetAllFilters()" class="px-3.5 py-2 text-xs font-semibold rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition font-bold shadow-lg shadow-cyan-500/25">
          Reset All Filters
        </button>
      </div>
    </header>

    <!-- PHASE 9: ADVANCED INTERACTIVE SLICERS -->
    <section class="acrylic-card rounded-2xl p-4 sm:p-5 space-y-3">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xs font-bold uppercase tracking-wider text-slate-300">Phase 9 • Interactive Executive Slicers (Power BI Standard)</span>
        </div>
        <span id="filter-status-indicator" class="text-xs text-slate-400">Active Records: <strong class="text-cyan-400 font-mono-num" id="slicer-count">100 / 100</strong></span>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 mb-1.5">📅 Date Window</label>
          <select id="filter-date" onchange="applyFilters()" class="w-full text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 transition">
            <option value="ALL">All Dates (Sep 01-10)</option>
          </select>
        </div>

        <div>
          <label class="block text-[11px] font-semibold text-slate-400 mb-1.5">🚦 Ride Status</label>
          <select id="filter-status" onchange="applyFilters()" class="w-full text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 transition">
            <option value="ALL">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div>
          <label class="block text-[11px] font-semibold text-slate-400 mb-1.5">📍 Pickup Location</label>
          <select id="filter-location" onchange="applyFilters()" class="w-full text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 transition">
            <option value="ALL">All Pickup Hubs</option>
          </select>
        </div>

        <div>
          <label class="block text-[11px] font-semibold text-slate-400 mb-1.5">🚗 Ride Type</label>
          <select id="filter-ride-type" onchange="applyFilters()" class="w-full text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 transition">
            <option value="ALL">All Ride Types</option>
          </select>
        </div>

        <div>
          <label class="block text-[11px] font-semibold text-slate-400 mb-1.5">💳 Payment Method</label>
          <select id="filter-payment" onchange="applyFilters()" class="w-full text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 transition">
            <option value="ALL">All Payment Methods</option>
          </select>
        </div>

        <div>
          <label class="block text-[11px] font-semibold text-slate-400 mb-1.5">👤 Driver ID</label>
          <select id="filter-driver" onchange="applyFilters()" class="w-full text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-200 px-3 py-2 outline-none focus:border-cyan-400 transition">
            <option value="ALL">All 10 Drivers</option>
          </select>
        </div>
      </div>
    </section>

    <!-- PHASE 4: 6 CORE REQUIRED KPI CARDS + 2 SUPPORTING -->
    <section class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Rides</span>
        <div class="my-1.5 text-2xl font-extrabold text-white font-mono-num" id="kpi-rides">100</div>
        <span class="text-[10px] text-cyan-400 font-semibold">Gross Dispatched</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Completed</span>
        <div class="my-1.5 text-2xl font-extrabold text-emerald-400 font-mono-num" id="kpi-completed">85</div>
        <span class="text-[10px] text-emerald-400 font-semibold" id="kpi-completed-pct">85.0% Fulfill</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Cancelled</span>
        <div class="my-1.5 text-2xl font-extrabold text-rose-400 font-mono-num" id="kpi-cancelled">15</div>
        <span class="text-[10px] text-rose-400 font-semibold" id="kpi-cancelled-pct">15.0% Churn</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Revenue</span>
        <div class="my-1.5 text-xl font-extrabold text-cyan-300 font-mono-num" id="kpi-revenue">₨36,466</div>
        <span class="text-[10px] text-cyan-400 font-semibold">Realized Inflow</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Average Fare</span>
        <div class="my-1.5 text-xl font-extrabold text-amber-400 font-mono-num" id="kpi-avg-fare">₨429.01</div>
        <span class="text-[10px] text-amber-400 font-semibold">Per Completed Trip</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Completion Rate</span>
        <div class="my-1.5 text-2xl font-extrabold text-emerald-400 font-mono-num" id="kpi-crate">85.0%</div>
        <span class="text-[10px] text-emerald-400 font-semibold">Target: &ge; 85%</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Average Rating</span>
        <div class="my-1.5 text-2xl font-extrabold text-yellow-400 font-mono-num" id="kpi-rating">4.27 ★</div>
        <span class="text-[10px] text-yellow-400 font-semibold">Completed Reviews</span>
      </div>

      <div class="acrylic-card rounded-2xl p-3.5 flex flex-col justify-between">
        <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Avg Distance</span>
        <div class="my-1.5 text-2xl font-extrabold text-indigo-300 font-mono-num" id="kpi-distance">13.8 km</div>
        <span class="text-[10px] text-indigo-400 font-semibold">Mean Route Run</span>
      </div>
    </section>

    <!-- PHASE 5: RIDE DEMAND ANALYSIS -->
    <section class="space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-2">
        <h2 class="text-base font-bold text-white tracking-wide flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Phase 5 • Ride Demand & Geographic Analysis
        </h2>
        <span class="text-xs text-slate-400">Temporal & Spatial Dynamics</span>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div class="acrylic-card rounded-2xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-white">Rides by Date (Demand Trend)</h3>
            <span class="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">Sep 01 - 10</span>
          </div>
          <div class="h-52 relative" id="chart-rides-by-date"></div>
        </div>

        <div class="acrylic-card rounded-2xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-white">Rides by Weekday (Demand Comparison)</h3>
            <span class="text-[10px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">Day Analysis</span>
          </div>
          <div class="h-52 relative" id="chart-rides-by-weekday"></div>
        </div>

        <div class="acrylic-card rounded-2xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-white">Top Pickup vs Drop-off Hubs</h3>
            <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Volume Share</span>
          </div>
          <div class="h-52 relative" id="chart-pickup-locations"></div>
        </div>
      </div>
    </section>

    <!-- PHASE 6: REVENUE ANALYSIS -->
    <section class="space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-2">
        <h2 class="text-base font-bold text-white tracking-wide flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Phase 6 • Financial & Revenue Intelligence
        </h2>
        <span class="text-xs text-slate-400">Cash Inflow, Channel Share & Vehicle Yield</span>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div class="acrylic-card rounded-2xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-white">Revenue by Payment Channel</h3>
            <span class="text-[10px] px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">Settlement Share</span>
          </div>
          <div class="h-52 flex items-center justify-center" id="chart-payment-rev"></div>
        </div>

        <div class="acrylic-card rounded-2xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-white">Revenue & Ticket Size by Ride Type</h3>
            <span class="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">Tier Economics</span>
          </div>
          <div class="h-52 relative" id="chart-ridetype-rev"></div>
        </div>

        <div class="acrylic-card rounded-2xl p-4">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-white">Realized Revenue by Pickup Hub</h3>
            <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Geographic Yield</span>
          </div>
          <div class="h-52 relative" id="chart-location-rev"></div>
        </div>
      </div>
    </section>

    <!-- PHASE 8: DRIVER PERFORMANCE LEAGUE TABLE -->
    <section class="acrylic-card rounded-2xl p-5 space-y-4">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 class="text-base font-bold text-white tracking-wide flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-indigo-400"></span> Phase 8 • Driver Performance League Table
          </h2>
          <p class="text-xs text-slate-400">Evaluated across Total Bookings, Completed, Cancelled, Realized Revenue, Rating, and Completion Rate</p>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-xs text-slate-400">Sort By:</span>
          <select id="driver-sort-by" onchange="renderDriverTable()" class="text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-cyan-400 px-3 py-1.5 outline-none font-bold">
            <option value="revenue">Total Revenue (PKR)</option>
            <option value="completed">Completed Rides</option>
            <option value="rating">Average Rating</option>
            <option value="crate">Completion Rate (%)</option>
          </select>
        </div>
      </div>

      <div class="overflow-x-auto custom-scrollbar rounded-xl border border-slate-800">
        <table class="w-full text-left text-xs whitespace-nowrap">
          <thead class="bg-slate-900/90 text-slate-300 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800">
            <tr>
              <th class="py-3 px-3.5">Driver ID</th>
              <th class="py-3 px-3.5 text-center">Total Rides</th>
              <th class="py-3 px-3.5 text-center">Completed</th>
              <th class="py-3 px-3.5 text-center">Cancelled</th>
              <th class="py-3 px-3.5 text-right">Realized Revenue</th>
              <th class="py-3 px-3.5 text-right">Avg Rating</th>
              <th class="py-3 px-3.5 text-right">Avg Distance</th>
              <th class="py-3 px-3.5 text-center">Completion Rate</th>
              <th class="py-3 px-3.5 text-center">Status Tier</th>
            </tr>
          </thead>
          <tbody id="driver-tbody" class="divide-y divide-slate-800/70 text-slate-200 font-mono-num">
          </tbody>
        </table>
      </div>
    </section>

    <!-- PHASE 7, 12, 13: STRATEGIC INSIGHTS & RECOMMENDATIONS -->
    <section class="grid grid-cols-1 lg:grid-cols-2 gap-5">
      <div class="acrylic-card rounded-2xl p-5 space-y-3">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <span class="text-cyan-400">💡</span> Phase 12 • 5 Data-Driven Business Insights
        </h3>
        <div class="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-cyan-300 block mb-0.5">1. Geographic Demand & Yield Concentration</strong>
            <strong>Finding:</strong> DHA generates 38.0% of total bookings and 42.2% of realized revenue (₨15,388).<br>
            <strong>Business Meaning:</strong> DHA is the platform's prime revenue engine. Protecting driver supply here is essential.
          </div>
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-emerald-300 block mb-0.5">2. Revenue Mirage vs True Reliability</strong>
            <strong>Finding:</strong> DRV-002 earned highest revenue (₨4,484) but suffered cancellations. DRV-001, 004, 010 achieved 100% completion (>₨4,000).<br>
            <strong>Business Meaning:</strong> Pure revenue incentives encourage trip cherry-picking; multi-criteria ranking rewards reliable partners.
          </div>
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-rose-300 block mb-0.5">3. Gulberg Churn & Driver Supply Mismatch</strong>
            <strong>Finding:</strong> Gulberg booked 20 rides but had 6 cancellations (30.0% churn) and the lowest avg fare (₨397.07).<br>
            <strong>Business Meaning:</strong> Traffic and lower fares cause driver rejections, leading to severe passenger churn.
          </div>
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-amber-300 block mb-0.5">4. Premium Tier Superior Unit Economics</strong>
            <strong>Finding:</strong> Premium trips average ₨558.05 (+30.3% over Standard) across similar travel distances (13.5 vs 12.5 km).<br>
            <strong>Business Meaning:</strong> High passenger willingness-to-pay makes Premium expansion the fastest path to margin growth.
          </div>
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-indigo-300 block mb-0.5">5. Digital Ecosystem vs Cash Dominance</strong>
            <strong>Finding:</strong> Cash generates 38.7% of revenue (₨14,115), but digital channels collectively command 61.3% (₨22,351).<br>
            <strong>Business Meaning:</strong> Heavy cash reliance creates operational disputes; digital onboarding accelerates trip turnover.
          </div>
        </div>
      </div>

      <div class="acrylic-card rounded-2xl p-5 space-y-3">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <span class="text-emerald-400">🚀</span> Phase 13 • 3 Strategic Actions & Architecture Note
        </h3>
        <div class="space-y-2.5 text-xs text-slate-300 leading-relaxed">
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-emerald-300 block mb-0.5">Action 1: Geofenced Fulfillment Boost for Gulberg</strong>
            Implement a ₨50 - ₨75 driver incentive for completed Gulberg pickups during high-demand days (Thursday & Saturday).<br>
            <strong>Expected Impact:</strong> Drops Gulberg churn from 30% to &lt;12%, recovering ~₨1,800 in lost daily bookings.
          </div>
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-cyan-300 block mb-0.5">Action 2: Multi-Factor Driver Priority Allocation</strong>
            Reward drivers with &ge;90% completion and &ge;4.3 ★ rating (DRV-001, 004, 010) with priority dispatch for Premium trips.<br>
            <strong>Expected Impact:</strong> Eliminates passenger abandonment and increases top-tier driver retention.
          </div>
          <div class="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
            <strong class="text-yellow-300 block mb-0.5">Action 3: 5% Instant Digital Settlement Incentive</strong>
            Offer 5% fare cashback on Card, UPI, and Wallet settlements to migrate cash volume.<br>
            <strong>Expected Impact:</strong> Reduces cash share from 38.7% to &lt;20%, curbing cash reconciliation friction.
          </div>
          <div class="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/50 text-cyan-200">
            <strong class="text-cyan-300 block mb-0.5">📌 Phase 7 Technical Architecture Notice</strong>
            The production dataset captures complete operational telemetry across 11 fields, but excludes customer_id and HH:MM timestamps. In strict compliance with internship integrity standards, customer metrics are evaluated via platform booking frequency and volume velocity rather than fabricated IDs.
          </div>
        </div>
      </div>
    </section>

    <!-- FOOTER -->
    <footer class="text-center text-xs text-slate-500 py-4 border-t border-slate-800/80">
      ZYROO Data Analytics Internship • Week 4 Power BI Production Build • Fully Offline Enabled & Localhost Compatible
    </footer>

  </div>

  <script>
    const RAW_RIDES = {json.dumps(records)};
    let filteredRides = [...RAW_RIDES];

    function initFilters() {{
      const dates = [...new Set(RAW_RIDES.map(r => r.date))].sort();
      const dateSelect = document.getElementById('filter-date');
      dates.forEach(d => {{
        const opt = document.createElement('option');
        opt.value = d;
        opt.textContent = d;
        dateSelect.appendChild(opt);
      }});

      const locations = [...new Set(RAW_RIDES.map(r => r.pickup_location))].sort();
      const locSelect = document.getElementById('filter-location');
      locations.forEach(l => {{
        const opt = document.createElement('option');
        opt.value = l;
        opt.textContent = l;
        locSelect.appendChild(opt);
      }});

      const rideTypes = [...new Set(RAW_RIDES.map(r => r.ride_type))].sort();
      const rtSelect = document.getElementById('filter-ride-type');
      rideTypes.forEach(rt => {{
        const opt = document.createElement('option');
        opt.value = rt;
        opt.textContent = rt;
        rtSelect.appendChild(opt);
      }});

      const payments = [...new Set(RAW_RIDES.map(r => r.payment_method))].sort();
      const paySelect = document.getElementById('filter-payment');
      payments.forEach(p => {{
        const opt = document.createElement('option');
        opt.value = p;
        opt.textContent = p;
        paySelect.appendChild(opt);
      }});

      const drivers = [...new Set(RAW_RIDES.map(r => r.driver_id))].sort();
      const drvSelect = document.getElementById('filter-driver');
      drivers.forEach(drv => {{
        const opt = document.createElement('option');
        opt.value = drv;
        opt.textContent = drv;
        drvSelect.appendChild(opt);
      }});
    }}

    function applyFilters() {{
      const dVal = document.getElementById('filter-date').value;
      const sVal = document.getElementById('filter-status').value;
      const lVal = document.getElementById('filter-location').value;
      const rtVal = document.getElementById('filter-ride-type').value;
      const pVal = document.getElementById('filter-payment').value;
      const drvVal = document.getElementById('filter-driver').value;

      filteredRides = RAW_RIDES.filter(r => {{
        if (dVal !== 'ALL' && r.date !== dVal) return false;
        if (sVal !== 'ALL' && r.ride_status !== sVal) return false;
        if (lVal !== 'ALL' && r.pickup_location !== lVal) return false;
        if (rtVal !== 'ALL' && r.ride_type !== rtVal) return false;
        if (pVal !== 'ALL' && r.payment_method !== pVal) return false;
        if (drvVal !== 'ALL' && r.driver_id !== drvVal) return false;
        return true;
      }});

      document.getElementById('slicer-count').textContent = `${{filteredRides.length}} / ${{RAW_RIDES.length}}`;
      updateKPIs(filteredRides);
      renderRidesByDate(filteredRides);
      renderRidesByWeekday(filteredRides);
      renderPickupLocations(filteredRides);
      renderPaymentRev(filteredRides);
      renderRideTypeRev(filteredRides);
      renderLocationRev(filteredRides);
      renderDriverTable();
    }}

    function resetAllFilters() {{
      document.getElementById('filter-date').value = 'ALL';
      document.getElementById('filter-status').value = 'ALL';
      document.getElementById('filter-location').value = 'ALL';
      document.getElementById('filter-ride-type').value = 'ALL';
      document.getElementById('filter-payment').value = 'ALL';
      document.getElementById('filter-driver').value = 'ALL';
      applyFilters();
    }}

    function updateKPIs(data) {{
      const total = data.length;
      const comp = data.filter(r => r.ride_status === 'Completed');
      const canc = data.filter(r => r.ride_status === 'Cancelled');
      const compCount = comp.length;
      const cancCount = canc.length;

      const rev = comp.reduce((acc, r) => acc + r.fare, 0);
      const avgFare = compCount > 0 ? (rev / compCount) : 0;
      const crate = total > 0 ? ((compCount / total) * 100) : 0;
      const cancRate = total > 0 ? ((cancCount / total) * 100) : 0;

      const rated = comp.filter(r => r.rating !== null && r.rating !== undefined);
      const avgRating = rated.length > 0 ? (rated.reduce((acc, r) => acc + r.rating, 0) / rated.length) : 0;

      const compDist = comp.reduce((acc, r) => acc + (r.distance_km || 0), 0);
      const avgDist = compCount > 0 ? (compDist / compCount) : 0;

      document.getElementById('kpi-rides').textContent = total;
      document.getElementById('kpi-completed').textContent = compCount;
      document.getElementById('kpi-completed-pct').textContent = `${{crate.toFixed(1)}}% Fulfill`;
      document.getElementById('kpi-cancelled').textContent = cancCount;
      document.getElementById('kpi-cancelled-pct').textContent = `${{cancRate.toFixed(1)}}% Churn`;
      document.getElementById('kpi-revenue').textContent = `₨${{rev.toLocaleString('en-US', {{maximumFractionDigits:0}})}}`;
      document.getElementById('kpi-avg-fare').textContent = `₨${{avgFare.toFixed(2)}}`;
      document.getElementById('kpi-crate').textContent = `${{crate.toFixed(1)}}%`;
      document.getElementById('kpi-rating').textContent = avgRating > 0 ? `${{avgRating.toFixed(2)}} ★` : '—';
      document.getElementById('kpi-distance').textContent = `${{avgDist.toFixed(1)}} km`;
    }}

    function renderRidesByDate(data) {{
      const box = document.getElementById('chart-rides-by-date');
      const dates = [...new Set(RAW_RIDES.map(r => r.date))].sort();
      const counts = dates.map(d => data.filter(r => r.date === d).length);
      const compCounts = dates.map(d => data.filter(r => r.date === d && r.ride_status === 'Completed').length);

      const maxVal = Math.max(...counts, 5);
      const w = 450, h = 180, padL = 30, padR = 20, padT = 20, padB = 30;
      const innerW = w - padL - padR;
      const innerH = h - padT - padB;

      const getX = (idx) => padL + (idx / (dates.length - 1)) * innerW;
      const getY = (val) => padT + innerH - (val / maxVal) * innerH;

      let pathTot = '';
      let pathComp = '';
      counts.forEach((c, i) => {{
        const x = getX(i), y = getY(c);
        pathTot += (i === 0 ? `M ${{x}} ${{y}}` : ` L ${{x}} ${{y}}`);
      }});
      compCounts.forEach((c, i) => {{
        const x = getX(i), y = getY(c);
        pathComp += (i === 0 ? `M ${{x}} ${{y}}` : ` L ${{x}} ${{y}}`);
      }});

      let dots = '';
      counts.forEach((c, i) => {{
        const x = getX(i), y = getY(c);
        const dStr = dates[i].split('-')[2];
        dots += `<circle cx="${{x}}" cy="${{y}}" r="3.5" fill="#38bdf8"/>`;
        dots += `<text x="${{x}}" y="${{h - 10}}" fill="#94a3b8" font-size="9" text-anchor="middle">Sep ${{dStr}}</text>`;
      }});

      box.innerHTML = `
        <svg viewBox="0 0 ${{w}} ${{h}}" class="w-full h-full">
          <line x1="${{padL}}" y1="${{padT}}" x2="${{padL}}" y2="${{padT + innerH}}" stroke="#1e293b" stroke-width="1"/>
          <line x1="${{padL}}" y1="${{padT + innerH}}" x2="${{w - padR}}" y2="${{padT + innerH}}" stroke="#1e293b" stroke-width="1"/>
          <path d="${{pathTot}}" fill="none" stroke="#38bdf8" stroke-width="2.5" stroke-linecap="round"/>
          <path d="${{pathComp}}" fill="none" stroke="#34d399" stroke-width="2" stroke-dasharray="3,3"/>
          ${{dots}}
        </svg>
      `;
    }}

    function renderRidesByWeekday(data) {{
      const box = document.getElementById('chart-rides-by-weekday');
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const dayFull = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      
      const counts = dayFull.map(df => {{
        return data.filter(r => {{
          const dt = new Date(r.date);
          const dayName = dt.toLocaleDateString('en-US', {{ weekday: 'long' }});
          return dayName === df;
        }}).length;
      }});

      const maxVal = Math.max(...counts, 5);
      const w = 450, h = 180, padL = 30, padR = 20, padT = 20, padB = 30;
      const innerW = w - padL - padR;
      const innerH = h - padT - padB;
      const barW = innerW / days.length - 12;

      let bars = '';
      days.forEach((d, i) => {{
        const val = counts[i];
        const barH = (val / maxVal) * innerH;
        const x = padL + i * (innerW / days.length) + 6;
        const y = padT + innerH - barH;
        bars += `
          <rect x="${{x}}" y="${{y}}" width="${{barW}}" height="${{barH}}" rx="4" fill="#818cf8" opacity="0.85"/>
          <text x="${{x + barW/2}}" y="${{y - 4}}" fill="#38bdf8" font-size="9" font-weight="bold" text-anchor="middle">${{val}}</text>
          <text x="${{x + barW/2}}" y="${{h - 10}}" fill="#94a3b8" font-size="9" text-anchor="middle">${{d}}</text>
        `;
      }});

      box.innerHTML = `
        <svg viewBox="0 0 ${{w}} ${{h}}" class="w-full h-full">
          <line x1="${{padL}}" y1="${{padT + innerH}}" x2="${{w - padR}}" y2="${{padT + innerH}}" stroke="#1e293b" stroke-width="1"/>
          ${{bars}}
        </svg>
      `;
    }}

    function renderPickupLocations(data) {{
      const box = document.getElementById('chart-pickup-locations');
      const locs = ['DHA', 'Gulberg', 'Bahria Town', 'Johar Town', 'Model Town'];
      const counts = locs.map(l => data.filter(r => r.pickup_location === l).length);
      const maxVal = Math.max(...counts, 5);

      const w = 450, h = 180, padL = 75, padR = 40, padT = 15, padB = 15;
      const innerW = w - padL - padR;
      const innerH = h - padT - padB;
      const barH = innerH / locs.length - 8;

      let bars = '';
      locs.forEach((l, i) => {{
        const val = counts[i];
        const bW = (val / maxVal) * innerW;
        const y = padT + i * (innerH / locs.length) + 4;
        bars += `
          <text x="${{padL - 8}}" y="${{y + barH/2 + 3}}" fill="#cbd5e1" font-size="10" text-anchor="end">${{l}}</text>
          <rect x="${{padL}}" y="${{y}}" width="${{bW}}" height="${{barH}}" rx="3" fill="#38bdf8" opacity="0.9"/>
          <text x="${{padL + bW + 6}}" y="${{y + barH/2 + 3}}" fill="#34d399" font-size="9" font-weight="bold">${{val}}</text>
        `;
      }});

      box.innerHTML = `
        <svg viewBox="0 0 ${{w}} ${{h}}" class="w-full h-full">
          ${{bars}}
        </svg>
      `;
    }}

    function renderPaymentRev(data) {{
      const box = document.getElementById('chart-payment-rev');
      const comp = data.filter(r => r.ride_status === 'Completed');
      const methods = ['Cash', 'Card', 'UPI', 'Wallet'];
      const colors = ['#38bdf8', '#818cf8', '#34d399', '#fbbf24'];

      const sums = methods.map(m => comp.filter(r => r.payment_method === m).reduce((acc, r) => acc + r.fare, 0));
      const total = sums.reduce((a, b) => a + b, 0);

      if (total === 0) {{
        box.innerHTML = '<span class="text-xs text-slate-500">No completed rides</span>';
        return;
      }}

      let curAngle = 0;
      let paths = '';
      let legend = '';

      sums.forEach((s, idx) => {{
        const pct = s / total;
        const angle = pct * 360;
        const rO = 70, rI = 45;
        const sRad = (curAngle - 90) * Math.PI / 180;
        const eRad = (curAngle + angle - 90) * Math.PI / 180;

        const x1 = 90 + rO * Math.cos(sRad), y1 = 90 + rO * Math.sin(sRad);
        const x2 = 90 + rO * Math.cos(eRad), y2 = 90 + rO * Math.sin(eRad);
        const x3 = 90 + rI * Math.cos(eRad), y3 = 90 + rI * Math.sin(eRad);
        const x4 = 90 + rI * Math.cos(sRad), y4 = 90 + rI * Math.sin(sRad);

        const la = angle > 180 ? 1 : 0;
        const d = `M ${{x1}} ${{y1}} A ${{rO}} ${{rO}} 0 ${{la}} 1 ${{x2}} ${{y2}} L ${{x3}} ${{y3}} A ${{rI}} ${{rI}} 0 ${{la}} 0 ${{x4}} ${{y4}} Z`;

        if (s > 0) {{
          paths += `<path d="${{d}}" fill="${{colors[idx]}}" stroke="#080d1a" stroke-width="2"/>`;
        }}
        legend += `
          <div class="flex items-center justify-between text-[11px]">
            <span class="flex items-center gap-1.5 text-slate-300">
              <span class="w-2.5 h-2.5 rounded-full" style="background-color:${{colors[idx]}}"></span> ${{methods[idx]}}
            </span>
            <span class="font-bold font-mono-num text-white">₨${{s.toLocaleString()}} (${{(pct*100).toFixed(1)}}%)</span>
          </div>
        `;
        curAngle += angle;
      }});

      box.innerHTML = `
        <div class="flex items-center gap-4 w-full justify-center">
          <svg viewBox="0 0 180 180" class="w-36 h-36">
            ${{paths}}
          </svg>
          <div class="space-y-1.5 flex-1 max-w-[200px]">
            ${{legend}}
          </div>
        </div>
      `;
    }}

    function renderRideTypeRev(data) {{
      const box = document.getElementById('chart-ridetype-rev');
      const comp = data.filter(r => r.ride_status === 'Completed');
      const tiers = ['Economy', 'Standard', 'Premium'];
      const sums = tiers.map(t => comp.filter(r => r.ride_type === t).reduce((acc, r) => acc + r.fare, 0));
      const avgs = tiers.map(t => {{
        const c = comp.filter(r => r.ride_type === t);
        return c.length > 0 ? (c.reduce((acc, r) => acc + r.fare, 0) / c.length) : 0;
      }});

      const maxVal = Math.max(...sums, 5000);
      const w = 450, h = 180, padL = 40, padR = 30, padT = 20, padB = 30;
      const innerW = w - padL - padR;
      const innerH = h - padT - padB;
      const barW = innerW / tiers.length - 30;

      let bars = '';
      tiers.forEach((t, i) => {{
        const val = sums[i];
        const barH = (val / maxVal) * innerH;
        const x = padL + i * (innerW / tiers.length) + 15;
        const y = padT + innerH - barH;
        bars += `
          <rect x="${{x}}" y="${{y}}" width="${{barW}}" height="${{barH}}" rx="4" fill="#38bdf8" opacity="0.85"/>
          <text x="${{x + barW/2}}" y="${{y - 12}}" fill="#38bdf8" font-size="9" font-weight="bold" text-anchor="middle">₨${{val.toLocaleString()}}</text>
          <text x="${{x + barW/2}}" y="${{y - 2}}" fill="#fbbf24" font-size="8" text-anchor="middle">Avg: ₨${{avgs[i].toFixed(0)}}</text>
          <text x="${{x + barW/2}}" y="${{h - 10}}" fill="#94a3b8" font-size="10" text-anchor="middle">${{t}}</text>
        `;
      }});

      box.innerHTML = `
        <svg viewBox="0 0 ${{w}} ${{h}}" class="w-full h-full">
          <line x1="${{padL}}" y1="${{padT + innerH}}" x2="${{w - padR}}" y2="${{padT + innerH}}" stroke="#1e293b" stroke-width="1"/>
          ${{bars}}
        </svg>
      `;
    }}

    function renderLocationRev(data) {{
      const box = document.getElementById('chart-location-rev');
      const comp = data.filter(r => r.ride_status === 'Completed');
      const locs = ['DHA', 'Bahria Town', 'Gulberg', 'Johar Town', 'Model Town'];
      const revs = locs.map(l => comp.filter(r => r.pickup_location === l).reduce((acc, r) => acc + r.fare, 0));
      const maxVal = Math.max(...revs, 5000);

      const w = 450, h = 180, padL = 75, padR = 55, padT = 15, padB = 15;
      const innerW = w - padL - padR;
      const innerH = h - padT - padB;
      const barH = innerH / locs.length - 8;

      let bars = '';
      locs.forEach((l, i) => {{
        const val = revs[i];
        const bW = (val / maxVal) * innerW;
        const y = padT + i * (innerH / locs.length) + 4;
        bars += `
          <text x="${{padL - 8}}" y="${{y + barH/2 + 3}}" fill="#cbd5e1" font-size="10" text-anchor="end">${{l}}</text>
          <rect x="${{padL}}" y="${{y}}" width="${{bW}}" height="${{barH}}" rx="3" fill="#34d399" opacity="0.9"/>
          <text x="${{padL + bW + 6}}" y="${{y + barH/2 + 3}}" fill="#38bdf8" font-size="9" font-weight="bold">₨${{val.toLocaleString()}}</text>
        `;
      }});

      box.innerHTML = `
        <svg viewBox="0 0 ${{w}} ${{h}}" class="w-full h-full">
          ${{bars}}
        </svg>
      `;
    }}

    function renderDriverTable() {{
      const sortBy = document.getElementById('driver-sort-by').value;
      const drivers = [...new Set(RAW_RIDES.map(r => r.driver_id))].sort();

      const stats = drivers.map(d => {{
        const allD = filteredRides.filter(r => r.driver_id === d);
        const compD = allD.filter(r => r.ride_status === 'Completed');
        const cancD = allD.filter(r => r.ride_status === 'Cancelled');
        const rev = compD.reduce((acc, r) => acc + r.fare, 0);
        const rated = compD.filter(r => r.rating !== null && r.rating !== undefined);
        const avgR = rated.length > 0 ? (rated.reduce((acc, r) => acc + r.rating, 0) / rated.length) : 0;
        const crate = allD.length > 0 ? ((compD.length / allD.length) * 100) : 0;
        const avgDist = compD.length > 0 ? (compD.reduce((acc, r) => acc + (r.distance_km || 0), 0) / compD.length) : 0;

        return {{
          id: d,
          total: allD.length,
          completed: compD.length,
          cancelled: cancD.length,
          revenue: rev,
          rating: avgR,
          distance: avgDist,
          crate: crate
        }};
      }});

      stats.sort((a, b) => {{
        if (sortBy === 'revenue') return b.revenue - a.revenue;
        if (sortBy === 'completed') return b.completed - a.completed;
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'crate') return b.crate - a.crate;
        return 0;
      }});

      const tbody = document.getElementById('driver-tbody');
      tbody.innerHTML = stats.map(s => {{
        const tierBadge = s.crate === 100 
          ? '<span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">🌟 100% Star</span>'
          : s.crate >= 80
          ? '<span class="px-2 py-0.5 rounded text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-bold">🟢 Consistent</span>'
          : '<span class="px-2 py-0.5 rounded text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/20 font-bold">🔴 Churn Alert</span>';

        return `
          <tr class="hover:bg-slate-800/40 transition">
            <td class="py-2.5 px-3.5 font-bold text-cyan-400">${{s.id}}</td>
            <td class="py-2.5 px-3.5 text-center text-white">${{s.total}}</td>
            <td class="py-2.5 px-3.5 text-center text-emerald-400 font-bold">${{s.completed}}</td>
            <td class="py-2.5 px-3.5 text-center ${{s.cancelled > 0 ? 'text-rose-400 font-bold' : 'text-slate-500'}}">${{s.cancelled}}</td>
            <td class="py-2.5 px-3.5 text-right font-bold text-white">₨${{s.revenue.toLocaleString()}}</td>
            <td class="py-2.5 px-3.5 text-right text-yellow-400 font-bold">${{s.rating > 0 ? s.rating.toFixed(2) + ' ★' : '—'}}</td>
            <td class="py-2.5 px-3.5 text-right text-slate-300">${{s.distance.toFixed(1)}} km</td>
            <td class="py-2.5 px-3.5 text-center font-bold ${{s.crate === 100 ? 'text-emerald-400' : s.crate >= 80 ? 'text-cyan-400' : 'text-rose-400'}}">${{s.crate.toFixed(0)}}%</td>
            <td class="py-2.5 px-3.5 text-center">${{tierBadge}}</td>
          </tr>
        `;
      }}).join('');
    }}

    function downloadCSV() {{
      const headers = ["ride_id","date","pickup_location","dropoff_location","distance_km","fare","payment_method","driver_id","ride_type","ride_status","rating"];
      const rows = filteredRides.map(r => [r.ride_id, r.date, r.pickup_location, r.dropoff_location, r.distance_km, r.fare, r.payment_method, r.driver_id, r.ride_type, r.ride_status, r.rating || '']);
      const csvContent = "data:text/csv;charset=utf-8," + [headers.join(",")].concat(rows.map(e => e.join(","))).join("\\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "zyroo_week4_powerbi_dataset_filtered.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }}

    document.addEventListener('DOMContentLoaded', () => {{
      initFilters();
      applyFilters();
    }});
  </script>
</body>
</html>
"""

with open('powerbi/ride-analytics-dashboard/index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

with open('week-04/index.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Generated HTML dashboards across root, powerbi, and week-04 successfully!")
